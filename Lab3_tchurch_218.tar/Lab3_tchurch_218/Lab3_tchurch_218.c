// Theodore Church G01127117
// CS 262, Lab Section 218
// Lab 3
#include <stdio.h>
#include <stdlib.h>
//declarations
int pickInt(int);
char changeCharacter(char);
void drawLine(int,char);
void drawSquare(int,char);
void drawRectangle(int,char);
void drawTriangle(int,char);
void displayOptions(char*);


int main(){
char userChar = ' ';
int userInt = 0;
char C = ' ';
while(C != 'Q' && C != 'q'){
	displayOptions(&C);
	switch(C){
	case 'C': 
		userChar = changeCharacter(userChar);
		break;
	case 'c':
		userChar = changeCharacter(userChar);
		break;
	case 'N':
		userInt = pickInt(userInt);
		break;
	case 'n':
		userInt = pickInt(userInt);
		break;
	case 'L': 
		drawLine(userInt,userChar);
		break;
	case 'l':
		drawLine(userInt,userChar);
		break;
	case 'S':
		drawSquare(userInt,userChar);
		break;
	case 's':
		drawSquare(userInt,userChar);
		break;
	case 'R':drawRectangle(userInt,userChar);
		break;
	case 'r':
		drawRectangle(userInt,userChar);
		break;
	case 'T':
		drawTriangle(userInt,userChar);
		break;
	case 't':
		drawTriangle(userInt,userChar);
		break;
	case 'Q':
		break; // Program ends
	case 'q':
		break; // Program ends
	default:
		printf("Invald character.\n");
		break;
	}	
}
return 0;
}
void displayOptions(char* inputChar){
	char inBuf[20];
	printf("Please input a character from the list:\n");
	printf("Enter/Change Character:			'C' or 'c'\n");
	printf("Enter/Change Number:			'N' or 'n'\n");
	printf("Draw Line :				'L' or 'l'\n");
	printf("Draw Square :				'S' or 's'\n");
	printf("Draw Rectangle:			 	'R' or 'r'\n");
	printf("Draw Triangle: (Left Justified) 	'T' or 't'\n");
	printf("Quit Program: 				'Q' or 'q'\n");
	fgets(inBuf,20,stdin);
	sscanf(inBuf,"%c",inputChar);	
}
char changeCharacter(char newChar){
	printf("Please enter a new character for your shapes to be printed as.\n");
	char inBuf[20];
	fgets(inBuf,20,stdin);
	sscanf(inBuf,"%c",&newChar);
	return newChar;
}
int pickInt(int someInt){
	char inBuf[20];
	int i = 0; //used for the while loop
	printf("Please enter an int value from 1 - 15\n");
	while(i == 0){
		fgets(inBuf,20,stdin);//read the input from keyboard and store it in buffer
		sscanf(inBuf,"%d",&someInt);//Extract the numerical value of inBuf and store it in someInt
		if(someInt < 1 || someInt > 15){
		printf("Not within the range(1-15) Try again\n");
		}
		else{
		i=i+1;
		}	
	}
	return someInt;
}
void drawLine(int n, char c){
	int i;
	for(i = 0;i<n;i++){
		printf("%c\n", c);
	}
}
void drawSquare(int n, char c){
	int i;
	for(i=0; i<n; i++){
		int j;
		for(j=0; j<n; j++){
			printf("%c", c);
		}
		printf("\n");
	}
}
void drawRectangle(int n, char c){
	int i;
	for(i=0; i<(n+5); i++){
                int j;
		for(j=0; j<n; j++){
                        printf("%c", c);                                                                                                }
                printf("\n");
        }
}        	
void drawTriangle(int n, char c){
	int i;
	for(i=0; i<n; i++){
		int j;
		for(j = 0; j<(i+1); j++){
			printf("%c",c);
		}
		printf("\n");
	}
}
