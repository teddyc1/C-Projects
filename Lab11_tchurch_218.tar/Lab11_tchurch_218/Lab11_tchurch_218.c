/*Theodore Church G01127117
 * CS262 Lab Section 218
 * Lab 11
 */
#include <stdio.h>
#include <stdlib.h>
typedef struct node{
	int nodeInt;
	struct node *nextNode;
}Node;

Node *create(int num){
	Node *new = malloc(sizeof(Node));
	new->nodeInt = num;
	new->nextNode = NULL;
	return new;
}
void insertNodeSorted(Node **head,int num){
	int b=0;
	Node *i = *head;
	Node *new = (Node*)malloc(sizeof(Node));
	new->nodeInt = num;
	/*if(i == NULL){
		new->nextNode = NULL;
		head = new;
		b=1;
	}
	else if(i->nodeInt > num){
		new->nextNode = head;
		head = new;
		b=1;
	}*/
	while(b==0){
		if(i == NULL){                                                                                                                  new->nextNode = NULL;
        	        *head = new;
        	        b=1;
        	}
       		/*insert at beginning*/
        	else if(i->nodeInt > num){
                	new->nextNode = *head;
                	*head = new;
                	b=1;
        	} 
		else if(i->nextNode == NULL){
			new->nextNode = NULL;
			i->nextNode = new;
			b=1;
		}
		else if(i->nextNode->nodeInt > num){
			new->nextNode = i->nextNode;
			i->nextNode = new;
			b=1;
		}
		else{
		i=i->nextNode;
		}
	}
		
}
void printList(Node *head){
	/*print list in order */
	Node *temp = head;
	int i = 1;
	while(temp!= NULL){
		printf("Node %d value: %d\n",i,temp->nodeInt);
		temp = temp->nextNode;
		i++;
	}
}
void deleteList(Node **head){
	Node *del = *head;
	Node *next;
	while(del != NULL){
		next = del->nextNode;
		free(del);
		del = next;
	}
	*head = NULL;
}

int main(int argc, char* argv[]){
	if(argc!= 4){
		/*name, seed, nodes, maxNodeValue*/
		printf("Wrong number of arguments, exiting.\n");
	}
	int seed;
	int nodeCount;
	int maxNodeValue;
	Node *head = NULL;
	int i;
	int j;
	sscanf(argv[1],"%d",&seed);
	sscanf(argv[2],"%d",&nodeCount);
	sscanf(argv[3],"%d",&maxNodeValue);
	srand(seed);
	printf("Seed: %d Node count: %d Max value: %d\n",seed,nodeCount,maxNodeValue);
	for(i=0;i<nodeCount;i++){	
		j = (random()%maxNodeValue);
		printf("Adding %d to the list.\n",j);
		insertNodeSorted(&head,j);
	}
	printList(head);
	deleteList(&head);
	return 0;
}

