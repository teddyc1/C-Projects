// Theodore Church G01127117
// CS 262, Lab Section 218
// Project 1
#include <stdio.h>
#include <stdlib.h>

//declarations 
int craps(int*);
void passLine(int*,int*,int*,int*);
void dontPassLine(int*,int*,int*,int*);
int rollTheDice(int);
void betBank(int*,int*);

int main(void){
	char quit = 'n'; //Quit? y/n 
	int bankroll = 100.0;//Initial money. Min bet = 5.0
	printf("Welcome to the game of Craps. Please enter a number seed for the purpose of random number generation.\n");
	char inBuf[20];
	int seed = 0;
	fgets(inBuf, 20, stdin);
	sscanf(inBuf,"%d",&seed);
	srandom(seed);
	while(quit != 'Y' && quit != 'y'&& bankroll > 0){ //Can't play with no money
		craps(&bankroll);
		printf("here's your curent bankroll: %d\n", bankroll);
		printf("Press Y or y to quit. N or n to keep going.\n");
		fgets(inBuf,20,stdin);
		sscanf(inBuf,"%c",&quit);
	}
	printf("Here's your final bankroll: %d", bankroll);
	return 0;	
}
int craps(int *bankroll){
	printf("Pass line or Don't Pass Line? Input 1 for Pass Line, 2 for Don't Pass Line.\n");
	char inBuff[20];
	char inBufff[20];
	char conf = 'N';//confirmation
	int PL = 0;
	int currentBet = 0;
	int currentWinnings = 0;
	int firstTime = 1;//Used for betting on passLine/don'tPassLine
	fgets(inBuff,20,stdin);
	sscanf(inBuff,"%d",&PL);
	if(PL == 1){
		passLine(bankroll, &currentBet,&firstTime,&currentWinnings);
		firstTime--;
	}
	else if(PL == 2){
		dontPassLine(bankroll, &currentBet,&firstTime,&currentWinnings);
		firstTime--;
	}
	do{ 
	printf("Let it ride? (Y)es or (N)o?\n");
	fgets(inBufff,20,stdin);
	sscanf(inBufff,"%c",&conf);
		if(PL==1 && (conf =='Y'|| conf == 'y')&& (*bankroll)>0){//Y is used here in case the user selects 'N' on the first iteration
			passLine(bankroll, &currentBet,&firstTime, &currentWinnings);
		}
		else if(PL==2 && (conf == 'Y' || conf == 'y')&& (*bankroll)>0){
			dontPassLine(bankroll,&currentBet, &firstTime, &currentWinnings);
		}
	}while(conf =='Y' || conf == 'y');
	if(currentWinnings > 0){
		*bankroll += currentWinnings;
	}
	return 0;
}
void passLine(int *bankroll,int *currentBet, int *firstTime, int *currentWinnings){
	//7/11 win, 2,3,12 lose, else roll = point, roll point before 7 to win
	int startingBank = *bankroll;
	int i = 0;//Used for loop
        int j = 0;//used for loop
        int bet = *currentBet;//Amount being bet
        int bankBet;//Bank matches
	if(*firstTime == 1){
		printf("How much would you like to bet? Minimum bet is $5, no maximum bet is in place.\n");
		printf("Only full dollar bets accepted. (Example: $6, not $6.37)\n");
		printf("Your current bank balance is: %d\n",startingBank);
		while(i==0){	
			char inBuff[20];
			bet = 0;
			fgets(inBuff,20,stdin);
			sscanf(inBuff,"%d",&bet);
			if(bet >= 5 && bet <= startingBank){
				*bankroll -= bet;
				bankBet = bet;
				*currentBet = bet;
				i++;
			}
			else if(bet < 5){
				printf("Bet too low, minimum bet is $5.\n");
			}
			else{
				printf("You have %d dollars. You can't bet more than you have.\n",startingBank);
			}
		}
	}
	int points = 0;//not always used
	int diceTotal = rollTheDice(diceTotal);
	printf("Rolled: %d\n", diceTotal);
	switch(diceTotal){
		case 7: printf("Winner!\n");
			*currentWinnings += (bet+bankBet);
			break;
		case 11: printf("Winner!\n");
			*currentWinnings += (bet+bankBet);		
			break;
		case 2: printf("Loser!\n");
			*currentWinnings =0;
			break; 
		case 3: printf("Loser!\n");
			*currentWinnings =0;
			break;
		case 12: printf("Loser!\n");
			 *currentWinnings =0;
			 break;
		default: points += diceTotal;
			 break;
	}
	if(points > 0){
		j++;//used for rolling again
		//betBank(&bet,bankroll);	
	}
	while(j>0){
		diceTotal = rollTheDice(diceTotal);
		printf("Rolled: %d\n",diceTotal);
		if (diceTotal == 7){
			printf("Loser! \n");
			*currentWinnings =0;
			j=0;
		}
		else if(points == diceTotal){
			printf("Winner! \n");
			*currentWinnings += (bet+bankBet);
			j=0;
		}
		else{
			printf("Roll again.\n");
		}
	}
	printf("current amount won: %d\n", *currentWinnings);
}
void dontPassLine(int *bankroll,int *currentBet, int *firstTime, int *currentWinnings){
        //7/11 win, 2,3,12 lose, else roll = point, roll point before 7 to win
        int startingBank = *bankroll;
        int i = 0;//Used for loop
        int j = 0;//used for loop
        int bet = *currentBet;//Amount being bet 
        int bankBet;//Bank                                       
        if(*firstTime == 1){
        	printf("How much would you like to bet? Minimum bet is $5, no maximum bet is in place.\n");
        	printf("Only full dollar bets accepted. (Example: $6, not $6.37)\n");
        	printf("Your current bank balance is: %d\n",startingBank);
        	while(i==0){
        		char inBuff[20];
			int bet = 0;
			fgets(inBuff,20,stdin);
			sscanf(inBuff,"%d",&bet);
			if(bet >= 5 && bet <= startingBank){
                                *bankroll -= bet;
                                bankBet = bet;
                                *currentBet = bet;
                                i++;
                        }
			else if(bet < 5){
                                printf("Bet too low, minimum bet is $5.\n");
                        }
                        else{
                                printf("You have %d dollars. You can't bet more than you have.\n",startingBank);
                        }
                }
        }
        int points = 0;//not always used
        int diceTotal = rollTheDice(diceTotal);
        printf("Rolled: %d\n", diceTotal);
        switch(diceTotal){
                case 2: printf("Winner!\n");
                        *currentWinnings += (bet+bankBet);
                        break;
                case 3: printf("Winner!\n");
                        *currentWinnings += (bet+bankBet);
                        break;
                case 12: printf("Winner!\n");
                        *currentWinnings +=(bet+bankBet);
                        break;
                case 11: printf("Loser!\n");
                        *currentWinnings = 0;
                        break;
                case 7: printf("Loser!\n");
                         *currentWinnings = 0;
                         break;
                default: points += diceTotal;
                         break;
        }
	if(points > 0){
		j++;
	}				
	while(j>0){
                diceTotal = rollTheDice(diceTotal);
                printf("Rolled: %d\n",diceTotal);
                if (diceTotal == points){
                        printf("Loser! \n");
                        *currentWinnings = 0;
                        j=0;
                }
                else if(diceTotal == 7){
                        printf("Winner! \n");
                        *currentWinnings += (bet+bankBet);
                        j=0;
                }
                else{
                        printf("Roll again.\n");
                }
        }
        printf("current amount won: %d\n", *currentWinnings);
}
int rollTheDice(int dieTotal){
	int die1 = (random()%6)+1;
	printf("Rolling dice. Die 1 has rolled: %d\n",die1);
	int die2 = (random()%6)+1;
	printf("Rolling dice. Die 2 has rolled: %d\n",die2);
	return die1+die2;
}

//Unused, this was a method used for doubling the bet, I missunderstood how "let it ride" worked. 
void betBank(int *startBet,int *bank){
	int bankValue = *bank;
	int newBet = *startBet;
	if((newBet*2)>bankValue){
		printf("Not enough money to double bet\n");
	}
	else{
		printf("Would you like to double your bet? (Y)es or (N)o?\n");
        	char betDouble = 'N';
        	char betBuf[20];
        	fgets(betBuf,20,stdin);
        	sscanf(betBuf,"%c",&betDouble);
        	if(betDouble == 'Y' || betDouble == 'y'){
        		newBet *= 2;
        	}//No need to do anything if they said no
	}
	*startBet = newBet;
}
