/*Theodore Church, G01127117
 * CS 262, Lab section 218
 * Project 3
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

typedef struct _songnode{   
  char title[35];
  char artist[35];
  char album[35];
  double duration;
  struct _songnode *next;
}SongNode;

SongNode *createSongNode(char *title, char *artist, char *album, double duration){
	SongNode *tmp = (SongNode*)malloc(sizeof(SongNode));
	if(tmp == NULL){
		printf("Error allocating memory.\n");
		exit(0);
	}
	else{
		strcpy(tmp->title,title);
		strcpy(tmp->artist,artist);
		strcpy(tmp->album,album);
		tmp->duration = duration;
	}
	return tmp;
}
void printList(SongNode *head){
	/*print list in order */
	SongNode *temp = head;
	int i = 1;
	while(temp!= NULL){
		printf("Song Number: %d\nSong Name: %s\nArtist: %s\nAlbum: %s\nDuration: %.2lf\n",i,(temp->title),
											(temp->artist),
											(temp->album),
											(temp->duration));
		temp = temp->next;
		i++;
	}
}
void printSongList(SongNode *head){
	SongNode *temp = head;
	int i = 1;
        while(temp!= NULL){
                printf("Song Number: %d Song Name: %s\n",i,(temp->title));
		temp = temp->next;
		i++;
	}

}
int insertSortedOrder(SongNode **head,SongNode *newNode,int position){
	SongNode *tmp = *head;
	SongNode *previous;
	newNode->next = NULL;
	if(position==0){
		*head = newNode;
	}
	else if(tmp!=NULL && strcmp(tmp->title,newNode->title)>0){
			newNode->next = tmp;
			*head = newNode;
	}
	else{	
		while(tmp!=NULL){
			if(strcmp(tmp->title,newNode->title)>0){
				newNode->next = tmp;
				previous->next = newNode;
				break;	
			}
			else if(tmp->next == NULL){
                                tmp->next = newNode;
                                break;
                        }
			previous = tmp;
			tmp = tmp->next;
		}
	}
	return 0;
}
int insertSong(SongNode **head,SongNode *newNode,int position){
	int j = 1;
	SongNode *tmp = *head;
	if(position == 0 && tmp==NULL){/*new head must be made*/
		*head = newNode;
		newNode->next = NULL;	
	}
	else if(position == 0){
		newNode->next = tmp;
		*head = newNode;
	}
	else{ 
		while(j < position){
			if(tmp->next == NULL){
				newNode->next = NULL;
				tmp->next = newNode;
				break;
			}
			else{
				tmp = tmp->next;
				j++;
			}
		}	
		if(tmp->next == NULL){
			newNode->next = NULL;		
			tmp->next = newNode;
		}
		else{
			newNode->next = tmp->next;
			tmp->next=newNode;
		}
	}
	return 0;
}
double computeDuration(SongNode *head){
	double total;
	SongNode *tmp = head;
	while(tmp != NULL){
		total += tmp->duration;
		tmp = tmp->next;
	}
	return total;
}
SongNode *searchByTitle(SongNode *head, char *search){
	SongNode *tmp = head;
	int k;
	for(k=0;k<strlen(search);k++){
             	search[k] = toupper(search[k]);
        }
	while(tmp!=NULL){
		if(strcmp(tmp->title,search)==0){
			break;
		}
		tmp = tmp->next;
	}
	return tmp;
}
SongNode *removeSong(SongNode **head,SongNode *remNode){
	SongNode *tmp = *head;
	SongNode *previous;
	int i = -1;
	if(tmp!=NULL && (strcmp(tmp->title,remNode->title)==0)){
		*head = tmp->next;
		i++;
	}
	while(tmp!=NULL){
		/*compare song title to ensure the song matches */
		if((strcmp(tmp->title,remNode->title)==0)){
			break;
		}
		previous = tmp;
		tmp=tmp->next;
	}
	/*Now we have the node, time to change pointers */
	if(i!=0){	
		if(tmp->next==NULL){
			previous->next = NULL;
		}
		else{
			previous->next = tmp->next;
		}
	}
	return tmp;	
}
int deleteSong(SongNode **head,SongNode *delNode){
	int i = -1;
	SongNode *tmp = removeSong(head,delNode);
	if(tmp!= NULL){
		free(tmp);
		i++;
	}
	return i;
}
void deleteList(SongNode **head){
	SongNode *tmp = *head;
	SongNode *next;
	while(next!= NULL){
		next = tmp-> next;
		free(tmp);
		tmp = next;
	}
}
int getNodePosition(SongNode *head, char *search){
	int pos = -1;
	int k;
	SongNode *tmp = head;
	for(k=0;k<strlen(search);k++){
                search[k] = toupper(search[k]);
        }
	k = 0;
        while(tmp!=NULL){
                if(strcmp(tmp->title,search)==0){
                       	 pos = k;	
			 break;
                }
                tmp = tmp->next;
		k++;
        }
	return pos;
}
/*Menus. All options should be seperate functions. Some options are already implemented, others(mainly user input)I can do with a small switch case*/
void printMusicLibrary(){
	printf("Welcome to the music library!\n");
	printf("View all songs:		'1'\n");/*void printList*/
	printf("Search by title:	'2'\n");/*small amount of user input needed */
	printf("Add song to playlist:	'3'\n");/*needs to have the user input implemented*/
	printf("Return to playlist:	'4'\n");/*simple reprint, no need for function*/
}
void printPlaylistMenu(){
	printf("Welcome to your playlist menu!\n");
	printf("Print playlist:		'1'\n");/* voidPrintList*/
	printf("Show duration:		'2'\n");/* double duration*/
	printf("Search by title:	'3'\n");/* needs user input*/
	printf("Move a song up 1:	'4'\n");/* insert at x position*/ 
	printf("Move a song down 1:	'5'\n");/* ^ */
	printf("Remove a song:		'6'\n");/*small amount of user input */
	printf("Go to music library:	'7'\n");/*change menu*/
	printf("Quit:			'q'\n");/*add confirmation */
}
void printSongMenu(){
	printf("Welcome to the \"Add-A-Song\" menu.\n");
	printf("Add a song to the end:			'1'\n");/*doesn't need to be it's own function, I track # of songs, insert at 0 */
	printf("Add a song to the beginning:		'2'\n");/*insert at songcount++*/
	printf("Insert song at a specific position:	'3'\n");/*insert at x */
}
void printSong(SongNode *search, int position){
	printf("Song Title: %s\nArtist: %s\nAlbum: %s\nDuration: %.2lf\nSong Number: %d\n",(search->title),
											(search->artist),
											(search->album),
											(search->duration),
											position);
}
void moveSongUp(SongNode **playListHead){
	char title[35],inBuf[35];
	SongNode *tmp = *playListHead;
	if(playListHead==NULL){
		printf("Playlist is empty! Add songs first.\n");
        }
        else{
        	printf("Please enter the title of a song you'd like to move up 1 position in your playlist.\n");
               	fgets(inBuf,sizeof(inBuf),stdin);
                sscanf(inBuf,"%[^\n]",title);
                SongNode *search = searchByTitle(tmp,title);
                if(search != NULL){
                	int x = getNodePosition(tmp,title);
                	if(x>0){
               			removeSong(&tmp,search);
                        	insertSong(&tmp,search,x-1);           		                                                                                                                        printf("Your new playlist:\n");
                        	printList(tmp);
                	}	
                	else{
               			printf("Song already at top of playlist.\n");
                	}
                }
               	else{
                	printf("Song not found.\n");
              	}
	}
}
void moveSongDown(SongNode **playListHead,int playListCount){
	char title[35],inBuf[35];
        SongNode *tmp = *playListHead;
        if(playListHead==NULL){
                printf("Playlist is empty! Add songs first.\n");
        }
        else{
                printf("Please enter the title of a song you'd like to move down 1 position in your playlist.\n");
                fgets(inBuf,sizeof(inBuf),stdin);
                sscanf(inBuf,"%[^\n]",title);
                SongNode *search = searchByTitle(tmp,title);
                if(search != NULL){
                        int x = getNodePosition(tmp,title);
                        if(x!=(playListCount-1)){
                                removeSong(&tmp,search);
                                insertSong(&tmp,search,x+1);                                                                                                                                            printf("Your new playlist:\n");
                                printList(tmp);
                        }
                        else{
                                printf("Song already at bottom of playlist.\n");
                        }
                }
                else{                                                                                                                                                                           printf("Song not found.\n");
                }
        }		
}

int main(int argc, char *argv[]){
	FILE *file;
	char inBuf[40]/*40 gives me slightly extra room */,fileName[100]/*not always used*/,title[35],artist[35],album[35];
	char userInput;
	double duration;
	int i,songCount,playListCount=0;
	bool quit = false,libQuit = false;
	SongNode *head = NULL,*playListHead = NULL;
	if(argc != 2){
		printf("Wrong number of arguments. Please enter a file name to be read on the command line.Exiting.\n");
		exit(0);
	}
	else{
		/*Read file and create playlist*/
		file = fopen(argv[1],"r");
		while(file == NULL){
			printf("File cannot be read. Please input the name of a new file.\n");
			fgets(inBuf,sizeof(inBuf),stdin);
			sscanf(inBuf,"%s",fileName);
			file=fopen(fileName,"r");
		}
		i=0;
		songCount = 0;
		while(fgets(inBuf,sizeof(inBuf),file)!=NULL){
			switch(i){
				case 0:
					sscanf(inBuf,"%[^\n]",title);
					i++;
					break;
				case 1:
					sscanf(inBuf,"%[^\n]",artist);
                                        i++;
					break;
				case 2:
					sscanf(inBuf,"%[^\n]",album);
                                        i++;
					break;
				case 3:
					sscanf(inBuf,"%lf",&duration);
                                        i=0;
					SongNode *new = createSongNode(title,artist,album,duration);
					insertSortedOrder(&head,new,songCount);
					/*insertSong(&head,new,songCount);*/
					songCount++;			
					break;
			}
		}
		printf("Playlist downloaded!\nSong Count: %d\n",songCount);
		/* Menus and switch case here */
		while(!quit){
			libQuit = false;
			bool end = false;
			printPlaylistMenu();
			fgets(inBuf,sizeof(inBuf),stdin);
			sscanf(inBuf,"%c",&userInput);
			switch(userInput){
					/*If a case is longer than ~10 lines of code(brackets/break excluded) I'll write it as a function. */
				case '1':/*print playlist*/ 
					if(playListHead==NULL){
						printf("Playlist is empty! Add songs first.\n");
					}
					else{
						printList(playListHead);
					} 
					break;
				case '2':/*print duration*/
					if(playListHead==NULL){
						printf("PlayList is empty! Add songs first.\n");
					}
					else{
						double plDuration = computeDuration(playListHead);
						printf("Playlist duration is currently: %.2lf\n",plDuration);
					}
					break;
				case '3':/*search song*/
					if(playListHead==NULL){
						printf("Playlist is empty! Add songs first.\n");
					}
					else{
						printf("Please enter the title of a song you'd like to find in your playlist.\n");
						fgets(inBuf,sizeof(inBuf),stdin);
                        			sscanf(inBuf,"%[^\n]",title);
						SongNode *search = searchByTitle(playListHead,title);
						if(search != NULL){
							int x = getNodePosition(playListHead,title)+1;
							printSong(search,x);
						}
						else{
							printf("Song not found. Check spelling and try again.\n");
						}
					}
					break;
				case '4':/*move song up*/
					if(playListHead==NULL){
                                                printf("Playlist is empty! Add songs first.\n");
                                        }
					else{
						moveSongUp(&playListHead);
					}
					break;
				case '5':/*move song down*/
					if(playListHead==NULL){
						printf("Playlist is empty! Add songs first.\n");
                                        }                                                                                                                                                                       else{
						moveSongDown(&playListHead,playListCount);
					}
                                        break;
				case '6':/*remove song*/
					if(playListHead==NULL){                                                                                                                                                         printf("Playlist is empty! Add songs first.\n");
                                        }
                                        else{
						printf("Please enter the title of a song you'd like to remove from your playlist.\n");          	                                                                fgets(inBuf,sizeof(inBuf),stdin);                                                                                                                                       sscanf(inBuf,"%[^\n]",title);                                                                                                                                           SongNode *search = searchByTitle(playListHead,title);
						if(search!=NULL){
							search = removeSong(&playListHead,search);
							playListCount--;
							insertSortedOrder(&head,search,songCount);
						}
						else{
							printf("Song not found.\n");
						}
                                        }
                                        break;
				case '7':/*music library*/
					/*Yes this case is longer than my comment said it would be, I'm sorry. */
					while(!libQuit){
						printMusicLibrary();
						char libChoice;
						fgets(inBuf,sizeof(inBuf),stdin);
						sscanf(inBuf,"%c",&libChoice);
						switch(libChoice){
							case '1':/*print list*/
								printList(head);
								break;
							case '2':/*search by title*/
								printf("Please enter the title of a song you'd like to find in your playlist.\n");
                                                		fgets(inBuf,sizeof(inBuf),stdin);
                                                		sscanf(inBuf,"%[^\n]",title);
								SongNode *searchSong = searchByTitle(head,title);
								if(searchSong!=NULL){
                                                        		int x = getNodePosition(head,title)+1;
                                                        		printSong(searchSong,x);
                                                		}
								else{
									printf("Song not found. Check spelling and try again.\n");
								}
								break;
							case '3':/*add song*/
								printf("Please enter the title of a song you'd like to add to your playlist.\n");
                                                                fgets(inBuf,sizeof(inBuf),stdin);
                                                                sscanf(inBuf,"%[^\n]",title);
								SongNode *search = searchByTitle(head,title);
								if(search != NULL){
									char iUser;
									printSongMenu();
									fgets(inBuf,sizeof(inBuf),stdin);
									sscanf(inBuf,"%c",&iUser);
									while(!end){
										/*triple nested switch case */
										switch(iUser){
											case '1':/*end*/
												removeSong(&head,search);
												insertSong(&playListHead,search,playListCount);
												playListCount++;
												end=true;
												libQuit = true;
												break;
											case '2':/*start*/
												removeSong(&head,search);
                                                                                                insertSong(&playListHead,search,0);
                                                                                                playListCount++;
												end = true;
												libQuit = true;
                                                                                                break;
											case '3':/*x*/
												printf("Enter the position to input.\n");
												int iUser2 = -1;
												bool badUser = true;	
												while(badUser){
													fgets(inBuf,sizeof(inBuf),stdin);
													sscanf(inBuf,"%d",&iUser2);
													iUser2--;
													if(iUser2 >= 0 && iUser2 <=playListCount){
															badUser = false;
													}
													if(badUser){
														printf("Make sure your number is valid.\n");
													}
												}
												removeSong(&head,search);
                                                                                                insertSong(&playListHead,search,iUser2);
                                                                                                playListCount++;
												end = true;
												libQuit = true;
                                                                                                break;
										}
									}
								}
								else{
									printf("Song not found. Please check spelling and try again.\n");
								}
								break;
							case '4':/*return*/
								libQuit = true;
								break;		
						}
					}
					break;
				case 'q':/*quit*/
					printf("Are you sure you want to quit? Press q again.\n");
					fgets(inBuf,sizeof(inBuf),stdin);
                        		sscanf(inBuf,"%c",&userInput);
					if(userInput=='q'){
						quit=true;
					}
					break;
			}
		}
		deleteList(&playListHead);
		deleteList(&head);
		fclose(file);
	}
	return 0;
}
