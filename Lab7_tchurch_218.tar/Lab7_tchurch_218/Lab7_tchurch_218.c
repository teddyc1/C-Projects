/* Theodore Church G01127117
 * CS 262, Lab section 218
 * Lab 7
 */
#include <stdio.h>
#include <stdlib.h>

void InitializeArray(int*,const int);
void printArray(int*,const int);
void shuffleArray(int*,const int);
void swap(int*,int*);
int compare(const void*, const void*);

int main(int argc, char* argv[]){
	/*variables and seeding */
	int i = 0; /*used for loop*/
	int seed = atoi(argv[1]);
	int arrayLength = atoi(argv[2]);
	int *numArray;
	srandom(seed);
	/*variables and seeding */
	printf("Theodore Church - 218\nThis program will take the first command line int and use that to seed a random number generator.\n");
	printf("Then the program will allocate an array of N integers, N being the second command line input.\n");
	printf("After this the array is filled, randomized, and then sorted.\n"); 
	numArray = (int*)malloc(sizeof(int)*arrayLength);
	if(numArray == NULL){
		printf("Error allocating memory.\n");
		exit(0);
	}
	else{
		for(i=0;i<10;i++){
			printf("Iteration: %d\n",(i+1));
			InitializeArray(numArray,arrayLength);
			printArray(numArray,arrayLength);
			shuffleArray(numArray, arrayLength);
        		printArray(numArray, arrayLength);
        		qsort(numArray,arrayLength,sizeof(int),compare);
        		printArray(numArray, arrayLength);
		}
		free(numArray);
	}
	return 0;
}
void InitializeArray(int *numArray, const int arrayLength){
	int i;
	for(i = 0;i<arrayLength;i++){
		numArray[i] = i;
	}
}
void printArray(int *numArray, const int arrayLength){
	int i;
	for(i = 0;i<arrayLength;i++){
		printf("%d ",numArray[i]);
	}
	printf("\n");/*newline after array*/
}
void shuffleArray(int *numArray, const int arrayLength){
	int i;
	for(i =arrayLength-1;i >0;i--){
		int j = rand()%(i+1);
		swap(&numArray[i],&numArray[j]);
	}
}
void swap(int *a, int *b){
	int temp = *a;
	*a = *b;
	*b = temp;
}
int compare(const void *a, const void *b){
	return (*(int*)b - *(int*)a);
}
