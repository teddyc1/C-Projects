/*Theodore Church G01127117
//CS262, Section 218
//Lab 6
*/
#include <stdlib.h>
#include <stdio.h>

int main(void){
	/*file info*/
	int empID = 0;
	int lines = 0;/*How many lines to read*/
	char strName[30];
	char monthHired[5];
	int dayHired = 0;
	int yearHired = 0;
	float hourlyWage = 0;
	/*other variables used for the program*/
	char inBuf[20];
	char fileName[20];
	char lineContents[50];
	FILE *readFile;
	FILE *writeFile; 
	int i = 0;/*Used for loops*/
	printf("Please input the name of the file you'd like to scan.\n");
	fgets(inBuf,sizeof(inBuf),stdin);
	sscanf(inBuf,"%s",fileName);
	readFile = fopen(fileName,"r");
	if(readFile == NULL){
		printf("File does not exist. Try Again.\n");
		exit(0);
	}
	else{
		printf("Read file opened.\n");
	}
	printf("Please enter the name of the file you'd like to write to.\n");
	fgets(inBuf,sizeof(inBuf),stdin);
	sscanf(inBuf,"%s",fileName);
	writeFile = fopen(fileName,"w");
	if(writeFile == NULL){
		printf("File does not exist. Try Again.\n");
		exit(0);
	}
	else{
		printf("Write file opened.\n");
	}
	/*the first number is going to tell me how many lines to read */
	fgets(inBuf,sizeof(inBuf),readFile);
	sscanf(inBuf,"%d",&lines);
	/*The first line tells me how many more lines to read, no fgets!=null needed. It's assumed the file is formatted correctly*/
	for(i = 0; i< lines; i++){
			fgets(lineContents,50,readFile);
			sscanf(lineContents,"%d %[^,], %s %d %d %f", &empID,&strName,&monthHired,&dayHired,&yearHired,&hourlyWage);
			fprintf(writeFile,"%-20s %d  %s  %02d  %.2f  %d\n",strName, yearHired, monthHired, dayHired, hourlyWage, empID);
	}
	fclose(readFile);
	fclose(writeFile);
	printf("Program completed successfully.");
	return 0;
}
