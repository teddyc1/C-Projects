#ifndef LAB12_H
#define LAB12_H 

#define ARRAY_SIZE (100)
#define PARTIAL_SIZE (10)

#define PR(x)	#x

#endif
