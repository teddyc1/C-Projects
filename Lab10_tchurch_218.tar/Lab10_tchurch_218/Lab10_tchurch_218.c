/*Theodore Church G01127117
 * CS 262, Lab section 218
 * Lab 10
 */
#include <stdio.h>
#include <stdlib.h>

#define BYTETOBINARYPATTERN "%d%d%d%d%d%d%d%d"
#define PRINTBIN(x) printf(BYTETOBINARYPATTERN, BYTETOBINARY(x));
#define BYTETOBINARY(byte)  \
  (byte & 0x80 ? 1 : 0), \
  (byte & 0x40 ? 1 : 0), \
  (byte & 0x20 ? 1 : 0), \
  (byte & 0x10 ? 1 : 0), \
  (byte & 0x08 ? 1 : 0), \
  (byte & 0x04 ? 1 : 0), \
  (byte & 0x02 ? 1 : 0), \
  (byte & 0x01 ? 1 : 0)

void setlsbs(unsigned char *p, unsigned char b0){
	printf("b0 = ");
	PRINTBIN(b0);
	printf("\n");
	unsigned char copy;
	int i;
	int x;
	for(i=0;i<8;i++){
		copy = b0;
		copy = copy << (8-(i+1));
		copy = copy >> (8-(i+1));
		if(i>0){
			copy = copy >> i;
			copy = copy << i;
		}
		printf("copy = ");
        	PRINTBIN(copy);
        	printf("\n");
		x = p[i];
		x = x|copy;
		p[i] = x;	
	}	
}
unsigned char getlsbs(unsigned char *p){
	int i;
	unsigned char rChar;
	for(i=0;i<8;i++){
		
	}
	return rChar;
}
int main(int argc, char *argv){
	/* Take arugment from command line to seed random. Then preform functions */
	if(argc != 2){
		printf("Wrong number of arguments.(2 expected) Exiting.\n");
		exit(1);
	}
	srandom(argv[1]);
	int i;
	unsigned char *bites[8];
	unsigned char bee;
	for(i=0;i<8;i++){
		bites[i] = (random()%255);
		printf("Number %d: %u Binary: ",i,bites[i]);
		PRINTBIN((int)bites[i]);
		printf("\n");
	}
	bee = (random()%255);
	printf("byte0 = %u binary: ",bee);
	PRINTBIN((int)bee);
	printf("\n");
	setlsbs(&bites,bee);
	printf("bits shifted\n");
	printf("Modified array:\n");
	for(i = 0; i<8;i++){
		printf("Number %d: %u Binary: ",i,bites[i]);
                PRINTBIN((int)bites[i]);
                printf("\n");
	}
	return 0;
}
