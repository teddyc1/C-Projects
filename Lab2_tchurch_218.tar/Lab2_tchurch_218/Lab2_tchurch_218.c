//Theodore Church,  G01127117
//CS 262, Lab Section 218
//Lab 2
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
char inBuf[20];//Buffer to hold characters
double startAmount = 0;//variable to hold number from keyboard
double apr = 0;
int daysInt = 0;
double newPrincipal = 0;

printf("Please enter the starting amount of expenses on the credit card\n");//Prompt user to enter the starting amount
fgets(inBuf,20,stdin);//read the input from keyboard and store it in buffer
sscanf(inBuf,"%lf",&startAmount);//Extract the numerical value of inBuf and store it in someInt
if(startAmount < 0){//Check negative
	printf("Starting amount(%.2lf) can't be negative",startAmount);//Error message
	exit(0); //Exit
	}	
printf("Please enter the APR(Annual percentage rate) on the credit card\n");//Prompt user for APR
fgets(inBuf,20,stdin);//read input
sscanf(inBuf,"%lf",&apr);//save value as a double
if(apr < 0){ //Check negative
	printf("APR can't be less than 0. Input:(%.2lf)",apr);//Error message
	exit(0); //Exit
	}
apr = apr/100;//Turn it from a percent to a decimal for the calculation
printf("Please enter the number of days the money has been borrowed\n");//Prompt user for days
fgets(inBuf,20,stdin);//read input
sscanf(inBuf,"%d",&daysInt);//save days as an int
if(daysInt < 0){ //check negative
	printf("Days can't be negative. Input was: (%.2d)",daysInt);//Error Message
	exit(0);//Exit
	}
//P'=P(1+r/n)^(nt)
//P = original principal
//P' = new principal sum
//r = annual interest rate
//n = compounding frequency, assumed to be 12
//t = overall length of time in years
// Total compound interest = P' - P
double years =(double) daysInt / 365;
double x = 1+(apr/12); //used for calc
double y = (12*years);
newPrincipal = pow(x, y);
newPrincipal = newPrincipal * startAmount;
double interestAmount = newPrincipal - startAmount;
//expense amount, APR, number of days, amount of interest and total amount to be paid back
printf("Expense amount: (%.2lf)\n APR: (%.2lf)\n Days: %.2d\n Total Interest: %.2lf\n New Principal: %.2lf",startAmount,apr,daysInt,interestAmount,newPrincipal);
return 0;
}
