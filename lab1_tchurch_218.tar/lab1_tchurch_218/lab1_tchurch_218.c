/*
 *Theodore Church G01127117
 *CS 262, Lab Section 218
 *Lab1
 */
#include <stdio.h>
#include <stdlib.h>
int main(){
    printf("Hello world!\n");
    printf("My name is Theodore Church.\n");
    return 0;
} 
