/*Theodore Church
 *CS 262, 218
 *Lab 9
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void searchWord(char*,char**);

int main(int argc, char* argv[]){
	FILE *input;
	char inBuf[20];
	int words;
	int rows;
	int columns;
	int i;
	if(argc > 2){
		printf("Too many arguments.\n");
		exit(0);
	}
	else if(argc == 1){
		printf("Another arugment expected.\n");
	}
	else {
		input = fopen(argv[1],"r");
		if(input == NULL){
			printf("File does not exist.\n");
			exit(1);
		}
	}		
	fgets(inBuf,sizeof(inBuf),input);
	sscanf(inBuf,"%d %d %d",&words,&rows,&columns);
	printf("%d %d %d\n",words,rows,columns);
	char **wordBank = malloc(rows*sizeof(char*));
	char **xword = malloc(rows*sizeof(char*));
	for(i = 0;i<rows;i++){
		wordBank[i] = malloc((columns+1)*sizeof(char));
		xword[i] = malloc((columns+1)*sizeof(char));
	}
	char *hold = malloc(10*sizeof(char));
	char *holder = malloc(10*sizeof(char));
	if(wordBank == NULL || xword == NULL|| hold == NULL|| holder == NULL){
		printf("Memory not allocated.\n");
	}
	else{
		printf("Memory allocated correctly.\n");
		for(i = 0;i < (words+rows); i++){
			fgets(inBuf,20,input);
			if(i < words){
				sscanf(inBuf,"%[^\n]",hold);
				wordBank[i] = strdup(hold);
			}
			else if(i>=(words)){
				sscanf(inBuf,"%[^\n]",holder);
				xword[i-words]=strdup(holder);
			}
		}
		for(i = 0;i<words;i++){
			searchWord(wordBank[0],xword);
		}
		
	}
	return 0;
}
void searchWord(char *word, char **crossword){
	/* use strstr to search horizontally, then switch the array[i][j] j=i i=j, then search horizontally again
 	 * after this write to output.txt*/
}
