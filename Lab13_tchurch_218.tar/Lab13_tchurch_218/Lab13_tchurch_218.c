/*Theodore Church G01127117
 * CS262 , 218
 * Lab 13
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef struct item_struct{
	char name[25];
	int quantity;
	double price;
}Item;

void printMenu(){
	printf("Welcome to the menu: \n");
	printf("Add item to shopping cart:	    Press '1'.\n");
	printf("Print the current list of items:    Press '2'.\n");
	printf("Quit from program:		    Press 'r'.\n");
}
void resizeArray(Item **array,int *cartSize,int itemCount){
	*cartSize *= 2;
	Item *tmp; 
	tmp = (Item*)malloc((*cartSize * sizeof(Item)));
	if(tmp == NULL){
		printf("Shopping Cart full. \n");
		exit(0);
	}
	else{	
		memcpy(tmp,*array,(sizeof(Item))*itemCount);
		free(*array);
	}
	*array = tmp;
}
void printArray(Item *array,int count){
	int i;
	if(count == 0){
		printf("Nothing in cart yet!");
	}
	else{
		for(i=0;i<count;i++){
			printf("Item: %d\n\tItem name: %s\n\tQuantity: %d\n\tPrice: %.2lf\n",(i+1),
									 (array[i].name),
									 (array[i].quantity),
									 (array[i].price));
		}
	}
}

int main(void){
	/*Declarations */	
	Item *cart;
	char inbuf[25];
	char newName[25];
	char menuChoice;
	int cartSize;
	int itemCount = 0;/*Keep track of how many items we have*/
	int newQuantity;
	bool quit = false;
	double newPrice;
	/*Making Shopping Cart*/
	printf("Please enter how many different items you're shopping for today.\n");
	fgets(inbuf,sizeof(inbuf),stdin);
	sscanf(inbuf,"%d",&cartSize);
	cart = (Item*)malloc(cartSize * sizeof(Item));
	if(cart == NULL){
		printf("Error allocating cart memory. Exitting.\n");
		exit(0);
	}
	/*shopping*/
	while(!quit){
		printMenu();
		fgets(inbuf,sizeof(inbuf),stdin);
		sscanf(inbuf,"%c",&menuChoice);
		switch (menuChoice){
			case '1': 
				/*check size, resize, add item, itemcount++ */
				if(itemCount == cartSize){
					resizeArray(&cart,&cartSize,itemCount);
				}
				printf("Please enter the name of your item. (Max 24 characters)\n");/*max 25 because \0 */
				fgets(inbuf,sizeof(inbuf),stdin);
				sscanf(inbuf,"%s",newName);
				printf("Please enter the quantity of %s you'd like to buy.\n",newName);
				fgets(inbuf,sizeof(inbuf),stdin);
				sscanf(inbuf,"%d",&newQuantity);
				printf("Please enter the price of %s.($xx.xx, do not include the '$')\n",newName);
				fgets(inbuf,sizeof(inbuf),stdin);
				sscanf(inbuf,"%lf",&newPrice);
				strcpy(cart[itemCount].name,newName);
				cart[itemCount].quantity = newQuantity;
				cart[itemCount].price = newPrice;
				itemCount++;	
				break;
			case '2': 
				printArray(cart,itemCount);
				break;
			case 'r':
				quit = true; 
				break;
		}
	}
	free(cart);
	return 0;
}

